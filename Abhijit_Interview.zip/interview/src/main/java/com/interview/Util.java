package com.interview;

import java.util.Scanner;

public class Util {
    private Util() {}

    public static int readInt() {
        Scanner myInput = new Scanner( System.in );
        return myInput.nextInt();
    }
}
