package com.interview.player;

public interface PlayerState {
    public void play();
}
